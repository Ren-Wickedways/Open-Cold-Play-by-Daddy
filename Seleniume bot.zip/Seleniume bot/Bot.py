from selenium import webdriver
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC  # Shorten Expected Conditions to EC
import time

service = Service(executable_path="chromedriver.exe")
driver = webdriver.Chrome(service=service)

# Go to Google first, then wait for the element to load
driver.get("https://www.google.com/webhp")  # Open Google search

# Waits up to 5 seconds for the search bar element with class "gLFyf" to be loaded
WebDriverWait(driver, 5).until(
    EC.presence_of_element_located((By.CLASS_NAME, "gLFyf"))
)

# Once the search bar is present, interact with it
input_element = driver.find_element(By.CLASS_NAME, "gLFyf")
input_element.clear()  # Clear the search bar if anything is there
input_element.send_keys("Daddy" + Keys.ENTER)  # Type in 'Daddy' and hit Enter

# Waits up to 5 seconds for the search bar element with class "Coldplay" to be loaded
WebDriverWait(driver, 5).until(
    EC.presence_of_element_located((By.PARTIAL_LINK_TEXT,"Coldplay"))) 


link = driver.find_element(By.PARTIAL_LINK_TEXT,"Coldplay") #Finds text with the words "Coldplay"
link.click () #clicks the link

# Wait for 20 seconds to see the result before closing the browser
time.sleep(20)

# Close the browser
driver.quit()
